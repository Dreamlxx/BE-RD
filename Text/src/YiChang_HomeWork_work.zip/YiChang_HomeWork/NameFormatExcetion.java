package YiChang_HomeWork;

public class NameFormatExcetion extends RuntimeException{
    public NameFormatExcetion(String message) {
        super(message);
    }

    public NameFormatExcetion() {
    }
}
