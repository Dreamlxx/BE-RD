package YiChang_HomeWork;

public class AgeOutLoveExcetion extends RuntimeException{
    public AgeOutLoveExcetion() {
    }

    public AgeOutLoveExcetion(String message) {
        super(message);
    }
}
